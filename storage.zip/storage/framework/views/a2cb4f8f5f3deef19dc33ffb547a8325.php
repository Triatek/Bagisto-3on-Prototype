<div class="">
    <div class="shimmer w-[94px] h-[38px] rounded-md"></div>
</div>
<?php /**PATH D:\3on_Project\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/shimmer/datagrid/toolbar/filter.blade.php ENDPATH**/ ?>