<label <?php echo e($attributes->merge(['class' => 'mb-2 block text-base max-sm:text-sm max-sm:mb-1'])); ?>>
    <?php echo e($slot); ?>

</label>
<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Shop\src/resources/views/components/form/control-group/label.blade.php ENDPATH**/ ?>