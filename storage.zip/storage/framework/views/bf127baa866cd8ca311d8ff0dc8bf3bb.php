<tr <?php echo e($attributes->merge(['scope' => 'row', 'class' => 'dark:border-gray-800'])); ?>>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/table/thead/tr.blade.php ENDPATH**/ ?>