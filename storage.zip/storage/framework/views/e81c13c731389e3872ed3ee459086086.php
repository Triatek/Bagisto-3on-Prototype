<th <?php echo e($attributes->merge(['scope' => 'col', 'class' => 'whitespace-nowrap px-6 py-4 font-semibold'])); ?>>
    <?php echo e($slot); ?>

</th>
<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/table/th.blade.php ENDPATH**/ ?>