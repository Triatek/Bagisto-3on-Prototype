<v-products-carousel
    src="<?php echo e($src); ?>"
    title="<?php echo e($title); ?>"
    navigation-link="<?php echo e($navigationLink ?? ''); ?>"
>
    <?php if (isset($component)) { $__componentOriginal132717af6d5760662131ee7680a588cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal132717af6d5760662131ee7680a588cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.shimmer.products.carousel','data' => ['navigationLink' => $navigationLink ?? false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::shimmer.products.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['navigation-link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navigationLink ?? false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal132717af6d5760662131ee7680a588cf)): ?>
<?php $attributes = $__attributesOriginal132717af6d5760662131ee7680a588cf; ?>
<?php unset($__attributesOriginal132717af6d5760662131ee7680a588cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal132717af6d5760662131ee7680a588cf)): ?>
<?php $component = $__componentOriginal132717af6d5760662131ee7680a588cf; ?>
<?php unset($__componentOriginal132717af6d5760662131ee7680a588cf); ?>
<?php endif; ?>
<?php if (! $__env->hasRenderedOnce('9022f3b2-395a-4829-a7aa-d522bc1e2db0')): $__env->markAsRenderedOnce('9022f3b2-395a-4829-a7aa-d522bc1e2db0');
$__env->startPush('styles'); ?>
    <style>
        /* --- CSS Grid Produk --- */
        .custom-product-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 2rem;
        }
        @media (max-width: 1024px) {
            .custom-product-grid { grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
        }
        @media (max-width: 768px) {
            .custom-product-grid { grid-template-columns: repeat(2, 1fr); gap: 1rem; }
        }

        /* --- CSS Judul ala New Arrivals --- */
        .na-header {
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }
        .na-title {
            font-size: 48px;
            font-weight: 700;
            color: #000033;
            font-family: 'Playfair Display', serif;
            margin: 0;
            line-height: 1;
            z-index: 2;
            position: relative;
        }
        .na-underline {
            display: block;
            width: 250px; /* Diperlebar sedikit agar muat untuk kata "New Products" */
            height: 18px;
            background-color: #FFF9C4;
            margin-top: -12px;
            border-radius: 50%;
            transform: rotate(-2deg);
            z-index: 1;
        }
        
        /* Penyesuaian Judul di HP */
        @media (max-width: 768px) {
            .na-title { font-size: 32px; }
            .na-underline { width: 170px; height: 14px; margin-top: -8px; }
        }
    </style>
<?php $__env->stopPush(); endif; ?>
</v-products-carousel>

<?php if (! $__env->hasRenderedOnce('22bffb82-3e0c-4969-8849-ec6a844a7786')): $__env->markAsRenderedOnce('22bffb82-3e0c-4969-8849-ec6a844a7786');
$__env->startPush('scripts'); ?>
    <script
        type="text/x-template"
        id="v-products-carousel-template"
    >
        <div
            class="container mt-20 max-lg:px-8 max-md:mt-8 max-sm:mt-7 max-sm:!px-4"
            v-if="! isLoading && products.length"
        >
            <div class="relative flex justify-center items-center mb-10 mt-5">
                <div class="na-header">
                    <h2 class="na-title max-md:text-4xl max-sm:text-3xl">
                        {{ title }}
                    </h2>
                    <div class="na-underline"></div>
                </div>

                <div class="absolute right-0 top-1/2 -translate-y-1/2 hidden max-lg:flex" v-if="navigationLink">
                     <a :href="navigationLink" class="flex items-center gap-2 text-xl max-md:text-base">
                        <?php echo app('translator')->get('shop::app.components.products.carousel.view-all'); ?>
                        <span class="icon-arrow-right text-2xl"></span>
                    </a>
                </div>
            </div>

            <div
                ref="swiperContainer"
                class="custom-product-grid mt-10 max-md:mt-5"
            >
                <?php if (isset($component)) { $__componentOriginalce4ea8dd577f45125a0fa9f371a55f23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce4ea8dd577f45125a0fa9f371a55f23 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.products.card','data' => ['class' => 'w-full max-md:h-fit','vFor' => 'product in products.slice(0, 8)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::products.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full max-md:h-fit','v-for' => 'product in products.slice(0, 8)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce4ea8dd577f45125a0fa9f371a55f23)): ?>
<?php $attributes = $__attributesOriginalce4ea8dd577f45125a0fa9f371a55f23; ?>
<?php unset($__attributesOriginalce4ea8dd577f45125a0fa9f371a55f23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce4ea8dd577f45125a0fa9f371a55f23)): ?>
<?php $component = $__componentOriginalce4ea8dd577f45125a0fa9f371a55f23; ?>
<?php unset($__componentOriginalce4ea8dd577f45125a0fa9f371a55f23); ?>
<?php endif; ?>
            </div>

            <a
                :href="navigationLink"
                class="secondary-button mx-auto mt-5 block w-max rounded-2xl px-11 py-3 text-center text-base max-lg:mt-0 max-lg:hidden max-lg:py-3.5 max-md:rounded-lg"
                :aria-label="title"
                v-if="navigationLink"
            >
                <?php echo app('translator')->get('shop::app.components.products.carousel.view-all'); ?>
            </a>
        </div>

        <!-- Product Card Listing -->
        <template v-if="isLoading">
            <?php if (isset($component)) { $__componentOriginal132717af6d5760662131ee7680a588cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal132717af6d5760662131ee7680a588cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.shimmer.products.carousel','data' => ['navigationLink' => $navigationLink ?? false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::shimmer.products.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['navigation-link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navigationLink ?? false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal132717af6d5760662131ee7680a588cf)): ?>
<?php $attributes = $__attributesOriginal132717af6d5760662131ee7680a588cf; ?>
<?php unset($__attributesOriginal132717af6d5760662131ee7680a588cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal132717af6d5760662131ee7680a588cf)): ?>
<?php $component = $__componentOriginal132717af6d5760662131ee7680a588cf; ?>
<?php unset($__componentOriginal132717af6d5760662131ee7680a588cf); ?>
<?php endif; ?>
        </template>
    </script>

    <script type="module">
        app.component('v-products-carousel', {
            template: '#v-products-carousel-template',

            props: [
                'src',
                'title',
                'navigationLink',
            ],

            data() {
                return {
                    isLoading: true,

                    products: [],

                    offset: 323,

                    isScreenMax2xl: window.innerWidth <= 1440,
                };
            },

            mounted() {
                this.getProducts();
            },

            created() {
                window.addEventListener('resize', this.updateScreenSize);
            },

            beforeDestroy() {
                window.removeEventListener('resize', this.updateScreenSize);
            },

            methods: {
                getProducts() {
                    this.$axios.get(this.src + (this.src.includes('?') ? '&' : '?') + 'limit=8')
                        .then(response => {
                            this.isLoading = false;

                            this.products = response.data.data;
                        }).catch(error => {
                            console.log(error);
                        });
                },

                updateScreenSize() {
                    this.isScreenMax2xl = window.innerWidth <= 1440;
                },

                swipeLeft() {
                    const container = this.$refs.swiperContainer;

                    container.scrollLeft -= this.offset;
                },

                swipeRight() {
                    const container = this.$refs.swiperContainer;

                    // Check if scroll reaches the end
                    if (container.scrollLeft + container.clientWidth >= container.scrollWidth) {
                        // Reset scroll to the beginning
                        container.scrollLeft = 0;
                    } else {
                        // Scroll to the right
                        container.scrollLeft += this.offset;
                    }
                },
            },
        });
    </script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH D:\3on_Project\Bagisto-3on-Prototype\packages\Webkul\Shop\src/resources/views/components/products/carousel.blade.php ENDPATH**/ ?>