<div <?php echo e($attributes->merge(['class' => 'mb-4'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/form/control-group/index.blade.php ENDPATH**/ ?>