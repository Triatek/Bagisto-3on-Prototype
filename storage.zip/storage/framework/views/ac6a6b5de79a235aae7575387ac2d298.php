<?php for($i = 0; $i < 3; $i++): ?>
    <div class="border-b border-slate-300 p-4 dark:border-gray-800">
        <p class="shimmer h-[17px] w-[150px]"></p>
    </div>
<?php endfor; ?><?php /**PATH D:\3on_Project\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/shimmer/header/mega-search/categories.blade.php ENDPATH**/ ?>