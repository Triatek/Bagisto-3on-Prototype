<td <?php echo e($attributes->merge(['scope' => 'row', 'class' => 'whitespace-nowrap px-6 py-4 dark:bg-gray-800 text-gray-600 dark:text-gray-300'])); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/table/td.blade.php ENDPATH**/ ?>