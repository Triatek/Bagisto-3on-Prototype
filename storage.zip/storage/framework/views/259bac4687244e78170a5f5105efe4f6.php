<table <?php echo e($attributes->merge(['class' => 'w-full min-w-[800px] text-left text-sm'])); ?>>
    <?php echo e($slot); ?>

</table>

<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/table/index.blade.php ENDPATH**/ ?>