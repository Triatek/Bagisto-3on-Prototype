
<?php $productFlatRepository = app('Webkul\Product\Repositories\ProductFlatRepository'); ?>

<?php
    $channel = core()->getCurrentChannel();
    $locale = core()->getCurrentLocale();

    $newArrivals = $productFlatRepository->scopeQuery(function ($query) use ($channel, $locale) {
        return $query->where('status', 1)
                     ->where('visible_individually', 1)
                     ->where('channel', $channel->code)
                     ->where('locale', $locale->code)
                     ->orderBy('created_at', 'desc');
    })->paginate(8);
?>

<?php $__env->startPush('meta'); ?>
    <meta name="title" content="<?php echo e($channel->home_seo['meta_title'] ?? ''); ?>" />
    <meta name="description" content="<?php echo e($channel->home_seo['meta_description'] ?? ''); ?>" />
    <meta name="keywords" content="<?php echo e($channel->home_seo['meta_keywords'] ?? ''); ?>" />
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal2643b7d197f48caff2f606750db81304 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2643b7d197f48caff2f606750db81304 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.layouts.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($channel->home_seo['meta_title'] ?? ''); ?> <?php $__env->endSlot(); ?>

    <?php $__currentLoopData = $customizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $data = $customization->options; ?>

        <?php switch($customization->type):
            case ($customization::IMAGE_CAROUSEL): ?>
                <?php if (isset($component)) { $__componentOriginalf822cda9ef0d23eb334a82ea5494f8ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf822cda9ef0d23eb334a82ea5494f8ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.carousel.index','data' => ['options' => $data,'ariaLabel' => 'Image Carousel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'aria-label' => 'Image Carousel']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf822cda9ef0d23eb334a82ea5494f8ce)): ?>
<?php $attributes = $__attributesOriginalf822cda9ef0d23eb334a82ea5494f8ce; ?>
<?php unset($__attributesOriginalf822cda9ef0d23eb334a82ea5494f8ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf822cda9ef0d23eb334a82ea5494f8ce)): ?>
<?php $component = $__componentOriginalf822cda9ef0d23eb334a82ea5494f8ce; ?>
<?php unset($__componentOriginalf822cda9ef0d23eb334a82ea5494f8ce); ?>
<?php endif; ?>
                <?php break; ?>

            <?php case ($customization::STATIC_CONTENT): ?>
                <?php if(! empty($data['css'])): ?>
                    <?php $__env->startPush('styles'); ?>
                        <style><?php echo e($data['css']); ?></style>
                    <?php $__env->stopPush(); ?>
                <?php endif; ?>

                <?php if(! empty($data['html'])): ?>
                    <?php if(Str::contains($data['html'], 'na-wrapper-luar')): ?>
                        <?php if($newArrivals->count() > 0): ?>
                            <div class="na-wrapper-luar">
                                <div class="na-container-dalam">
                                    <div class="na-header">
                                        <h2 class="na-title">New Arrivals</h2>
                                        <div class="na-underline"></div>
                                    </div>

                                    <div class="na-grid">
                                        <?php $__currentLoopData = $newArrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                // Pastikan ambil Product model (bukan hanya flat)
                                                $product = $item->product ?? $item;
                                                $image = product_image()->getProductBaseImage($product);
                                                $imageUrl = $image['medium_image_url'] ?? $image['small_image_url'] ?? '';
                                            ?>

                                            <div class="na-card">
                                                <a href="<?php echo e(route('shop.product_or_category.index', $product->url_key)); ?>">
                                                    <div class="na-image-box" style="background-image: url('<?php echo e($imageUrl); ?>');">
                                                        <span class="na-badge-new">New Arrival</span>
                                                    </div>
                                                </a>

                                                <a href="<?php echo e(route('shop.product_or_category.index', $product->url_key)); ?>" class="na-prod-name">
                                                    <?php echo e($product->name); ?>

                                                </a>

                                                <div class="na-prod-price">
                                                    <?php echo $product->getTypeInstance()->getPriceHtml(); ?>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="na-btn-wrapper">
                                        <a href="#" class="na-btn">View More</a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if(Str::contains($data['html'], 'public/storage')): ?>
                            <?php echo str_replace('public/storage', 'storage', $data['html']); ?>

                        <?php else: ?>
                            <?php echo $data['html']; ?>

                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
                <?php break; ?>

            <?php case ($customization::CATEGORY_CAROUSEL): ?>
            <div id="koleksi-kategori" style="scroll-margin-top: 100px;">
                <?php if (isset($component)) { $__componentOriginal55b1251dd0fd6403a4d59156278578f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal55b1251dd0fd6403a4d59156278578f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.categories.carousel','data' => ['title' => $data['title'] ?? '','src' => route('shop.api.categories.index', $data['filters'] ?? []),'navigationLink' => route('shop.home.index'),'ariaLabel' => 'Category Carousel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::categories.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['title'] ?? ''),'src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('shop.api.categories.index', $data['filters'] ?? [])),'navigation-link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('shop.home.index')),'aria-label' => 'Category Carousel']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal55b1251dd0fd6403a4d59156278578f2)): ?>
<?php $attributes = $__attributesOriginal55b1251dd0fd6403a4d59156278578f2; ?>
<?php unset($__attributesOriginal55b1251dd0fd6403a4d59156278578f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55b1251dd0fd6403a4d59156278578f2)): ?>
<?php $component = $__componentOriginal55b1251dd0fd6403a4d59156278578f2; ?>
<?php unset($__componentOriginal55b1251dd0fd6403a4d59156278578f2); ?>
<?php endif; ?>
                </div>
                <?php break; ?>
                <?php case ($customization::PRODUCT_CAROUSEL): ?>
                <?php if (isset($component)) { $__componentOriginalc7b94830d947988d2b7058066254da2b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7b94830d947988d2b7058066254da2b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'shop::components.products.carousel','data' => ['title' => $data['title'] ?? '','src' => route('shop.api.products.index', $data['filters'] ?? []),'navigationLink' => route('shop.home.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('shop::products.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data['title'] ?? ''),'src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('shop.api.products.index', $data['filters'] ?? [])),'navigation-link' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('shop.home.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7b94830d947988d2b7058066254da2b)): ?>
<?php $attributes = $__attributesOriginalc7b94830d947988d2b7058066254da2b; ?>
<?php unset($__attributesOriginalc7b94830d947988d2b7058066254da2b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7b94830d947988d2b7058066254da2b)): ?>
<?php $component = $__componentOriginalc7b94830d947988d2b7058066254da2b; ?>
<?php unset($__componentOriginalc7b94830d947988d2b7058066254da2b); ?>
<?php endif; ?>
                <?php break; ?>
        <?php endswitch; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2643b7d197f48caff2f606750db81304)): ?>
<?php $attributes = $__attributesOriginal2643b7d197f48caff2f606750db81304; ?>
<?php unset($__attributesOriginal2643b7d197f48caff2f606750db81304); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2643b7d197f48caff2f606750db81304)): ?>
<?php $component = $__componentOriginal2643b7d197f48caff2f606750db81304; ?>
<?php unset($__componentOriginal2643b7d197f48caff2f606750db81304); ?>
<?php endif; ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* minimal CSS — copy your full styles here if perlu */
        .na-wrapper-luar { width: 100%; display: flex; justify-content: center; background-color: #fff; padding: 60px 0; }
        .na-container-dalam { width: 100%; max-width: 1440px; padding: 0 20px; box-sizing: border-box; }
        .na-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 30px; }
        .na-image-box { width: 100%; aspect-ratio: 1/1; background-size: cover; background-position: center; background-color: #f5f5f5; }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\3on_Project\Bagisto-3on-Prototype\packages\Webkul\Shop\src/resources/views/home/index.blade.php ENDPATH**/ ?>