<thead <?php echo e($attributes->merge(['class' => 'border-gray-200 bg-gray-50 text-sm text-gray-600 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300'])); ?>>
    <?php echo e($slot); ?>

</thead>
<?php /**PATH D:\3on\Bagisto-3on-Prototype\packages\Webkul\Admin\src/resources/views/components/table/thead/index.blade.php ENDPATH**/ ?>